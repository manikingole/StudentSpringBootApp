package com.thekiranacademy.TheKiranAcademyProject.Service;

import java.util.List;
import java.util.Optional;

import com.thekiranacademy.TheKiranAcademyProject.Entity.Student;

public interface StudentsService {

	public List<Student> getAllStudent();

	public Optional<Student> getStudentById(Long studentId);

	public Student addStudent(Student student);

	public Student updateStudent(Long studentId, Student student);

	public String deleteStudent(long parseLong);

	



	

}
