package com.thekiranacademy.TheKiranAcademyProject.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.thekiranacademy.TheKiranAcademyProject.Entity.Student;


public interface StudentsDao extends JpaRepository<Student, Long> {

}
