package com.thekiranacademy.TheKiranAcademyProject.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thekiranacademy.TheKiranAcademyProject.Dao.StudentsDao;
import com.thekiranacademy.TheKiranAcademyProject.Entity.Student;

@Service
public class StudentsServiceImpl implements StudentsService {

	@Autowired
	StudentsDao studentDao;

	@Override
	public List<Student> getAllStudent() {
		return studentDao.findAll();
	}

	@Override
	public Optional<Student> getStudentById(Long studentId) {
		return studentDao.findById(studentId);
	}

	@Override
	public Student addStudent(Student student) {
		return studentDao.save(student);
	}

	@Override
	public Student updateStudent(Long studentId, Student student) {
		Optional<Student> existingStudentOptional = studentDao.findById(studentId);
		if (existingStudentOptional.isPresent()) {
			Student existingStudent = existingStudentOptional.get();
			existingStudent.setfName(student.getfName());
			return studentDao.save(existingStudent);
		}
		return null;
	}

	@Override
	public String deleteStudent(long parseLong) {
		Student entity = studentDao.getOne(parseLong);
		studentDao.delete(entity);
		return "Delete StudentData SuccessFully";
	}

}
