package com.thekiranacademy.TheKiranAcademyProject.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.thekiranacademy.TheKiranAcademyProject.Entity.Student;
import com.thekiranacademy.TheKiranAcademyProject.Service.StudentsService;

@RestController
@RequestMapping("/student")
public class StudentsController {
	@Autowired
	StudentsService studentService;
	
	
	// get the student
		@GetMapping
		public List<Student> getAllStudent() {
			return this.studentService.getAllStudent();
		}

		// get single student
		@GetMapping("/{studentId}")
		public Optional<Student> getStudentById(@PathVariable String studentId) {
			return this.studentService.getStudentById(Long.parseLong(studentId));
		}

		// add student
		@PostMapping
		public Student addStudent(@RequestBody Student student) {
			return this.studentService.addStudent(student);
		}

		// update student
		@PutMapping("/{studentId}")
		public Student updateStudent(@PathVariable Long studentId,@RequestBody Student student) {
			return this.studentService.updateStudent(studentId,student);
		}

		// delete student
		@DeleteMapping("/{studentId}")
		public String deleteStudent(@PathVariable String studentId) {
			return this.studentService.deleteStudent(Long.parseLong(studentId));

		}
	

}
