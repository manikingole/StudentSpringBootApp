package com.thekiranacademy.TheKiranAcademyProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheKiranAcademyProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
